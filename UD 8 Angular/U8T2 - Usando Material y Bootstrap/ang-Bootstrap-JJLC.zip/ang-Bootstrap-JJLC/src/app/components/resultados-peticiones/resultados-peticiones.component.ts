import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resultados-peticiones',
  templateUrl: './resultados-peticiones.component.html',
  styleUrls: ['./resultados-peticiones.component.css']
})
export class ResultadosPeticionesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
