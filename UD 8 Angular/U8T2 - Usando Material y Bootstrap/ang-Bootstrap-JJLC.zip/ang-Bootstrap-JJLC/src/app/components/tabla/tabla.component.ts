import { Component, OnInit } from '@angular/core';

interface Country {
  name: string;
  flag: string;
  dEntregas: number;
  dAdmin: number;
  dCompleta: number;
  entregadas: number;
  poblAdmin: number;
  poblCompleta: number;
}

const COUNTRIES: Country[] = [
  {
    name: 'Andalucía',
    flag: '2/20/Flag_of_Andalucía.svg',
    dEntregas: 17075200,
    dAdmin: 146989754,
    dCompleta: 2,
    entregadas: 3,
    poblAdmin: 2,
    poblCompleta: 2
  },
  {
    name: 'Aragón',
    flag: '1/18/Flag_of_Aragon.svg',
    dEntregas: 9976140,
    dAdmin: 36624199,
    dCompleta: 3,
    entregadas: 1,
    poblAdmin: 7,
    poblCompleta: 6
  },
  {
    name: 'Asturias',
    flag: '3/3e/Flag_of_Asturias.svg',
    dEntregas: 9629091,
    dAdmin: 324459463,
    dCompleta: 2,
    entregadas: 5,
    poblAdmin: 1,
    poblCompleta: 4
  },
  {
    name: 'Baleares',
    flag: '7/7b/Flag_of_the_Balearic_Islands.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  },
  {
    name: 'C.Valenciana',
    flag: 'd/df/Flag_of_the_Land_of_Valencia_%28official%29.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  },
  {
    name: 'Canarias',
    flag: 'd/dc/Canary_Islands_CoA.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  },
  {
    name: 'Castilla La Mancha',
    flag: 'e/eb/Escudo_de_Castilla-La_Mancha.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  },
  {
    name: 'Castilla y Leon',
    flag: '1/13/Flag_of_Castile_and_León.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  },
  {
    name: 'Madrid',
    flag: '6/67/Escudo_de_Madrid.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  },
  {
    name: 'Navarra',
    flag: '4/4b/Escudo_de_Navarra_%28oficial%29.svg',
    dEntregas: 9596960,
    dAdmin: 1409517397,
    dCompleta: 1,
    entregadas: 4,
    poblAdmin: 3,
    poblCompleta: 1
  }
];

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {
  countries = COUNTRIES;
  constructor() { }

  ngOnInit(): void {
  }

}
