import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datos-comunidades',
  templateUrl: './datos-comunidades.component.html',
  styleUrls: ['./datos-comunidades.component.css']
})
export class DatosComunidadesComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
