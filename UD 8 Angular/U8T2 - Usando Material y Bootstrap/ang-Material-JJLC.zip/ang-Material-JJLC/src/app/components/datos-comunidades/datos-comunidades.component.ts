import { Component, OnInit } from '@angular/core';

//select
interface CCAA {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-datos-comunidades',
  templateUrl: './datos-comunidades.component.html',
  styleUrls: ['./datos-comunidades.component.sass']
})
export class DatosComunidadesComponent implements OnInit {

  //select
  ccaas: CCAA[] = [
    {value: 'andalucia-0', viewValue: 'Andalucía'},
    {value: 'aragon', viewValue: 'Aragón'},
    {value: 'asturias', viewValue: 'Asturias'},
    {value: 'baleares', viewValue: 'Baleares'},
    {value: 'Valenciana', viewValue: 'C.Valenciana'},
    {value: 'Canarias', viewValue: 'Canarias'},
    {value: 'Cantabria', viewValue: 'Cantabria'},
    {value: 'Castilla', viewValue: 'Castilla La Mancha'},
    {value: 'Leon', viewValue: 'Castilla y Leon'},
    {value: 'Cataluña', viewValue: 'Cataluña'},
    {value: 'Ceuta', viewValue: 'Ceuta'},
    {value: 'Extremadura', viewValue: 'Extremadura'},
    {value: 'Galicia', viewValue: 'Galicia'},
    {value: 'Rioja', viewValue: 'La Rioja'},
    {value: 'Madrid', viewValue: 'Madrid'},
    {value: 'Melilla', viewValue: 'Melilla'},
    {value: 'Murcia', viewValue: 'Murcia'},
    {value: 'Navarra', viewValue: 'Navarra'},
    {value: 'País', viewValue: 'País Vasco'}
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
