import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultadosPeticionesComponent } from './resultados-peticiones.component';

describe('ResultadosPeticionesComponent', () => {
  let component: ResultadosPeticionesComponent;
  let fixture: ComponentFixture<ResultadosPeticionesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResultadosPeticionesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResultadosPeticionesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
