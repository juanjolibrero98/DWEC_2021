import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  dEntregadas: number;
  comunidad: string;
  dAdmin: number;
  dCompleta: number;
  entregadas: number;
  admin: number;
  completa: number;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {comunidad: 'Andalucía', dEntregadas: 1, dAdmin: 1.0079, dCompleta: 3, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Aragón', dEntregadas: 3, dAdmin: 4.0026, dCompleta: 4, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Asturias', dEntregadas: 4, dAdmin: 6.941, dCompleta: 6, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Baleares', dEntregadas: 2, dAdmin: 9.0122, dCompleta: 8, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Canarias', dEntregadas: 4, dAdmin: 10.811, dCompleta: 1, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Cantabria', dEntregadas: 5, dAdmin: 12.0107, dCompleta: 2, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Ceuta', dEntregadas: 6, dAdmin: 14.0067, dCompleta: 1, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Galicia', dEntregadas: 1, dAdmin: 15.9994, dCompleta: 4, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Madrid', dEntregadas: 9, dAdmin: 18.9984, dCompleta: 5, entregadas: 1, admin: 2, completa: 3},
  {comunidad: 'Murcia', dEntregadas: 1, dAdmin: 20.1797, dCompleta: 4, entregadas: 1, admin: 2, completa: 3},
];

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.sass']
})
export class TablaComponent implements OnInit {
  displayedColumns: string[] = ['comunidad', 'dEntregadas', 'dAdmin', 'dCompleta', 'entregadas', 'admin', 'completa'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit(): void {
  }

}
