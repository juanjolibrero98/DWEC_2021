import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { centrosFP } from '../common/interfaz';

@Injectable({
  providedIn: 'root'
})
export class GetAllInfoService {

  constructor(private _http: HttpClient) {
    console.log("Servicio creado");
  }

  filtros: any[];

  _url1 : string = 'assets/ofertas.json';// o poner https://raw.githubusercontent.com/iesalixar/dwec_codigo_teoria/main/ofertas.json?token=ANG57X4GICZWTUT4ROH4ZHLAHE44U

  get_Info(): Observable<centrosFP[] > {
    return this._http.get<centrosFP[]>(this._url1);
  }

}
