import { TestBed } from '@angular/core/testing';

import { GetAllInfoService } from './get-all-info.service';

describe('GetAllInfoService', () => {
  let service: GetAllInfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetAllInfoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
