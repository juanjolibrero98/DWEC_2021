import { Component, Input, OnInit } from '@angular/core';
import { centrosFP, valorSelect } from 'src/app/common/interfaz';
import { tabla } from 'src/app/common/TablaClass';
import { GetAllInfoService } from 'src/app/services/get-all-info.service';
import { TablaComponent } from '../tabla/tabla.component';


@Component({
  selector: 'app-filtros',
  templateUrl: './filtros.component.html',
  styleUrls: ['./filtros.component.css']
})
export class FiltrosComponent implements OnInit {

  @Input()
  tabla_component: TablaComponent;

 //valores de los select
  famiValor: string;
  cicloValor: string;
  provinciaValor: string;
  tipoValor: string;
  turnoValor: string;
  BilingueValor: string;
  dualValor: string;

  dataSource: centrosFP[];

  //array para guardar los datos que mostrare en la tabla del otro componente
  tabla: tabla[];

  //familia para html
  familia: any[];

  //Nombre del ciclo para html
  nomCiclo: any[];

  //tipo para html
  tipo: any[];

  //turno html
  turno: any[];

  //bilingue html 
  bilingue: any[];

  //dual html
  dual: any[];

  //provincia html 
  provincia: any[];

  filtrosArray: valorSelect[] = [];

  constructor(public cetros : GetAllInfoService) { }

  ngOnInit(): void {
    this.obtenerTabla();
  }
  obtenerTabla(){
    this.cetros.get_Info().subscribe(response => {
      // console.log(response);      
      this.dataSource = response;
  
      this.tabla_component.tablaa = response;
  
      //array familia familia
      let array = [];
      //array nombreCiclo
      let nomCiclo = [];
      //array tipo 
      let tipoArray = [];

      //array turno
      let turnoArray = [];

      //array bilingue
      let bilingueArray = [];

      //array dual
      let dualArray = [];

      let y = 0;
      let nomCi = 0;
      let tip = 0;
      let turn = 0;
      let bilin = 0;
      let du = 0;
      //recorro array de items de la respuesta del json
      for (let i = 0; i < response["items"].length; i++) {
        // console.log(response["items"][i]);
      
        //familia
        if(!array.includes(response["items"][i].familia)){
          array[y] = response["items"][i].familia;
          y++;
        }

        //nombre del ciclo
        if(!nomCiclo.includes(response["items"][i].nombre_ciclo)){
          nomCiclo[nomCi] = response["items"][i].nombre_ciclo;
          nomCi++;
        }

        //tipo publico, privado etc
        if(!tipoArray.includes(response["items"][i].tipo)){
          tipoArray[tip] = response["items"][i].tipo;
          tip++;
        }

        //turno mañana, tarde etc
        if(!turnoArray.includes(response["items"][i].turno)){
          turnoArray[turn] = response["items"][i].turno;
          turn++;
        }

        //bilingue si , no etc
        if(!bilingueArray.includes(response["items"][i].bilingue)){
          bilingueArray[bilin] = response["items"][i].bilingue;
          bilin++;
        }

        //dual  si , no etc
        if(!dualArray.includes(response["items"][i].dual)){
          dualArray[du] = response["items"][i].dual;
          du++;
        }
        

      }
      array.sort();
      this.familia = array;
      nomCiclo.sort();
      this.nomCiclo = nomCiclo;
      tipoArray.sort();
      this.tipo = tipoArray;
      turnoArray.sort();
      this.turno = turnoArray;
      bilingueArray.sort();
      this.bilingue = bilingueArray;
      dualArray.sort();
      this.dual = dualArray;
      // console.log("this.familia");
      // console.log(this.familia);
      // console.log("array");
      // console.log(array);


      // array provincia
      let provinciaArray = [];
      let provi = 0;
      //recorro el array de info_centros
      for (let i = 0; i < response["info_centros"].length; i++) {
        //localidad ....etc
        if(!provinciaArray.includes(response["info_centros"][i].codigo_provincia)){
          provinciaArray[provi] = response["info_centros"][i].codigo_provincia;
          provi++;
        }
      }
      provinciaArray.sort();
      this.provincia = provinciaArray;

      let arrayCompleto = [];
      for (let i = 0; i < response.length; i++) {
        arrayCompleto.push(response);
      }

    })
  }

  filtrar(){
    console.log(this.famiValor+"\n"+
          this.cicloValor+"\n"+
          this.provinciaValor+"\n"+
          this.tipoValor+"\n"+
          this.turnoValor+"\n"+
          this.BilingueValor+"\n"+
          this.dualValor);

    let envio = new valorSelect();
    // envio.familia = this.famiValor;
  
    envio.nombreCiclo = this.cicloValor;
    envio.provincia = this.provinciaValor;
    envio.tipo = this.tipoValor;
    envio.turno = this.turnoValor;
    envio.bilingue = this.BilingueValor;
    envio.dual = this.dualValor;
    this.filtrosArray.push(envio);

    this.tabla_component.tablaRespuesta = this.filtrosArray;
    
    // this.cetros.filtros = filtrosArray;
    console.log("this.cetros.filtros");
    console.log(this.cetros.filtros);

    this.tabla_component.filtrarTabla();
  }


}
