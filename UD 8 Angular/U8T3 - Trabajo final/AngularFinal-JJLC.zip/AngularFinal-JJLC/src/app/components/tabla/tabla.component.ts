import { Component, Input, OnInit } from '@angular/core';
import { centrosFP, valorSelect } from 'src/app/common/interfaz';
import { tabla } from 'src/app/common/TablaClass';
import { GetAllInfoService } from 'src/app/services/get-all-info.service';
import { FiltrosComponent } from '../filtros/filtros.component';

class tablaInfo {
  codigoCentro: string;
  nombreCentro: string;
  direccionCentro: string;
  tlfCentro: string;
  localidadCentro: string;
  provincia: string;
  nombreCiclo: string;
  tipo: string;
  turno: string;
  bilingue: string;
  dual: string;
}
class itemsInfo {
  nombreCiclo: string;
  tipo: string;
  turno: string;
  bilingue: string;
  dual: string;
  codigoCentro: string;
}
class centroInfo {
  provincia: string;
  codigoCentro: string;
  nombreCentro: string;
  direccionCentro: string;
  tlfCentro: string;
  localidadCentro: string;
}

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {


  //collapse centro
  public isCollapsed = true;

  @Input()
  filtros_component: FiltrosComponent;

  //array para guardar los datos que mostrare en la tabla del otro componente
  // tablaRespuesta: tabla[];
  tablaRespuesta: valorSelect[];

  tablaa: centrosFP[];

  arrayCompletoTabla: tablaInfo[] = [];

  centros: centroInfo[] = [];
  items:  itemsInfo[] = []; 


  constructor(public cetros : GetAllInfoService) { }

  ngOnInit(): void {

  }
  mostrar(tabla){
    if(document.getElementById(tabla).className == "collapse"){
      document.getElementById(tabla).className ="collapse.show";
    }else{
      document.getElementById(tabla).className ="collapse";
    }
  }
  
  filtrarTabla(){
    console.log("Valor de los select en el componente tabla");
    // console.log(this.cetros.filtros);

    //aqui tengo el valor de los select
    console.log(this.tablaRespuesta);

    //aqui tengo el valor de todo el json
    console.log("Todo el json en el componente tabla");
    console.log(this.tablaa);

    for (let y = 0; y < this.tablaa["info_centros"].length; y++) {
      if((this.tablaa["info_centros"][y].codigo_provincia == this.tablaRespuesta[0].provincia) || (this.tablaa["info_centros"][y].codigo_provincia == undefined)){
          let centroTabla = new centroInfo();
          centroTabla.codigoCentro = this.tablaa["info_centros"][y].codigo;
          centroTabla.nombreCentro =  this.tablaa["info_centros"][y].nombre;
          centroTabla.direccionCentro = this.tablaa["info_centros"][y].direccion;
          centroTabla.tlfCentro = this.tablaa["info_centros"][y].telefono;
          centroTabla.localidadCentro = this.tablaa["info_centros"][y].localidad;
          centroTabla.provincia = this.tablaa["info_centros"][y].codigo_provincia;
          this.centros.push(centroTabla);
      }
    }
    console.log("Prueba de la buena loco");
    console.table(this.centros);//todos los centros que tienen el codigo que esta en el select


    for (let i = 0; i < this.tablaa["items"].length; i++) {
      if(((this.tablaa["items"][i].nombre_ciclo == this.tablaRespuesta[0].nombreCiclo) || (this.tablaa["items"][i].nombre_ciclo == undefined) ) && 
          ((this.tablaa["items"][i].tipo == this.tablaRespuesta[0].tipo) || (this.tablaa["items"][i].tipo == undefined)) && 
          ((this.tablaa["items"][i].turno == this.tablaRespuesta[0].turno ) || (this.tablaa["items"][i].turno == undefined))&&
          ((this.tablaa["items"][i].bilingue == this.tablaRespuesta[0].bilingue) || (this.tablaa["items"][i].bilingue == undefined)) && 
          ((this.tablaa["items"][i].dual == this.tablaRespuesta[0].dual) || (this.tablaa["items"][i].dual == undefined))){
            let itemsTabla = new itemsInfo();
           itemsTabla.nombreCiclo = this.tablaa["items"][i].nombre_ciclo;
           itemsTabla.tipo = this.tablaa["items"][i].tipo;
           itemsTabla.turno = this.tablaa["items"][i].turno;
           itemsTabla.bilingue = this.tablaa["items"][i].bilingue;
           itemsTabla.dual = this.tablaa["items"][i].dual;
           itemsTabla.codigoCentro = this.tablaa["items"][i].codigo;
           this.items.push(itemsTabla);
           console.log("Prueba de la buena loco0000000000000000000000");
          console.table(this.items);//todo aqui tengo los items
      }  
    }

    for(let x = 0 ; x < this.centros.length; x++){
      for (let z = 0; z < this.items.length; z++) {
        if(this.centros[x].codigoCentro == this.items[z].codigoCentro){
          let tabla = new tablaInfo();
          tabla.bilingue = this.items[z].bilingue;
          tabla.codigoCentro = this.centros[x].codigoCentro;
          tabla.direccionCentro = this.centros[x].direccionCentro;
          tabla.dual = this.items[z].dual;
          tabla.localidadCentro = this.centros[x].localidadCentro;
          tabla.nombreCentro = this.centros[x].nombreCentro;
          tabla.nombreCiclo = this.items[z].nombreCiclo;
          tabla.provincia = this.centros[x].provincia;
          tabla.tipo = this.items[z].tipo;
          tabla.tlfCentro = this.centros[x].tlfCentro;
          tabla.turno = this.items[z].turno;
          this.arrayCompletoTabla.push(tabla);
          console.log("Ptuuuuuuuuuuuuuuuuuuu");
          console.table(this.arrayCompletoTabla);
        }
      }
    }

  }
}
