export class tabla{
    codigo: string;
    codigo_provincia: string;
    direccion: string;
    localidad: string;
    nombre: string;
    telefono: string;
    bilingue: string;
    dual: string;
    familia: string;
    nombre_ciclo: string;
    tipo: string;
    turno: string;
}