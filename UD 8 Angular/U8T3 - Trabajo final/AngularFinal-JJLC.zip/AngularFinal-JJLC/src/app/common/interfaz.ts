export interface centrosFP{
    request_time: "";
    info_centros: [
        codigo: string,
        codigo_provincia: string,
        direccion: string,
        localidad: string,
        nombre: string,
        telefono: string,
    ];
    items: [
        bilingue: string,
        codigo: string,
        codigo_ciclo: string,
        dual: string,
        familia: string,
        nombre_ciclo: string,
        tipo: string,
        turno: string,
    ];
}


export class valorSelect {
    familia: string;
    nombreCiclo: string;
    provincia: string;
    tipo: string;
    turno: string;
    bilingue: string;
    dual: string;
  }